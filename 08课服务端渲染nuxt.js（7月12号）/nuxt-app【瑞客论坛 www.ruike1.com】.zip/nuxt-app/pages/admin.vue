<template>
    <div>
        admin
    </div>
</template>

<script>
    export default {
        middleware: ['auth']
    }
</script>

<style lang="scss" scoped>

</style>