<template>
  <div>
    <ul>
      <li>
        <router-link to="/detail/1">web全栈</router-link>
      </li>
      
    </ul>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
</style>