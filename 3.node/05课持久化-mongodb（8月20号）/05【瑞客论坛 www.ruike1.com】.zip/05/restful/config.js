module.exports = {
    db: {
        url:"mongodb://localhost:27017/test",
        options: { useNewUrlParser: true }
    }
}