module.exports = {
    schema: {
        mobile: { type: String, required: true },
        // password: { type: String, required: true },
        realName: { type: String, required: true },
    }
}

